/**
 * 
 */
package gnu.prolog;

