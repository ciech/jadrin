/**
 * Contains built in predicates and the prolog files that build them in.
 */
package gnu.prolog.vm.buildins;

