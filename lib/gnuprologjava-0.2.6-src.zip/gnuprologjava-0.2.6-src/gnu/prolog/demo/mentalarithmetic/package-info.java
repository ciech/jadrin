/**
 * This package contains a simple demo program showing how to use gnu.prolog
 * in java programs in order to do backtracking search. It does this by using 
 * Prolog to do backtracking search to find suitable questions to ask for mental 
 * arithmetic problems.
 */
package gnu.prolog.demo.mentalarithmetic;

